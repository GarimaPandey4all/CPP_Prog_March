#include <iostream>

using namespace std;

int main()
{
    int marks[5], sum = 0, percentage;

    cout<<"Enter your marks:";
    for(int i = 0; i < 5; i++)
    {
        cin>>marks[i];
    }

    for(int i = 0; i < 5; i++)
    {
        sum += marks[i];
    }

    cout<<"Total Marks is:"<<sum<<endl;

    percentage = sum / 5;

    cout<<"Percentage is:"<<percentage<<endl;

    if(percentage >= 50 && percentage <= 60)
    {
        cout<<"Grade D";
    }
    else if(percentage >= 60 && percentage <= 70)
    {
        cout<<"Grade C";
    }
    else if(percentage >= 70 && percentage <= 80)
    {
        cout<<"Grade B";
    }
    else if(percentage >= 80 && percentage <= 100)
    {
        cout<<"Grade A";
    }
    else
    {
        cout<<"Fail...";
    }

    return 0;
}
