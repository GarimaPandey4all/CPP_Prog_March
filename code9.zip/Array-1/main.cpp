#include <iostream>

using namespace std;

int main()
{
    //Traditional way of initialization
    int arr[5] = {1, 2, 3, 4, 5};

    cout<<"First value of an Array is:"<<arr[0]<<endl;

    cout<<"Values in Array are:\n";
    for(int i = 0; i < 5; i++)
    {
        cout<<arr[i]<<"  ";
    }

    int lists[5];

    cout<<"\nEnter values in an Array:\n";
    for(int i = 0; i < 5; i++)
    {
        cin>>lists[i];
    }

    cout<<"\nValues in an Array:\n";
    for(int i = 0; i < 5; i++)
    {
        cout<<lists[i]<<"  ";
    }

    //Compile Time Initialization
    int marks[] = {3, 6, 8, 3};

    cout<<"\nValues in an Array:\n";
    for(int i = 0; i < 4; i++)
    {
        cout<<marks[i]<<"  ";
    }

    return 0;
}
