#include <iostream>
#define  MONTHS 12 //Macros - fixed variable values

using namespace std;

int main()
{
    int days[MONTHS] = {31, 28, 31, 30, 30, 31, 30, 31, 30, 30, 31, 31};

    for(int i = 0; i < MONTHS; i++)
    {
        cout<<i + 1<<" month has "<<days[i]<<" days"<<endl;
    }

    return 0;
}
