#include <iostream>

using namespace std;

int main()
{
    int matrix1[5][5], matrix2[5][5], result[5][5], rows, cols;

    cout<<"Enter number of rows:";
    cin>>rows;

    cout<<"Enter number of columns:";
    cin>>cols;

    cout<<"Enter values in matrix-1:\n";
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            cin>>matrix1[i][j];
        }
    }


    cout<<"Enter values in matrix-2:\n";
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            cin>>matrix2[i][j];
        }
    }


    cout<<"Values in matrix-1:\n";
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            cout<<matrix1[i][j]<<"  ";
        }
        cout<<endl;
    }

    cout<<"Values in matrix-2:\n";
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            cout<<matrix2[i][j]<<"  ";
        }
        cout<<endl;
    }

    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            result[i][j] = matrix1[i][j] + matrix2[i][j];
        }
    }

    cout<<"Addition is:\n";
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            cout<<result[i][j]<<"  ";
        }
        cout<<endl;
    }

    return 0;
}
