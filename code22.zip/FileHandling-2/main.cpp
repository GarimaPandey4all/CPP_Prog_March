#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    ofstream outfile("Test.txt", ios::app); // app: append

    outfile<<"Hello World"<<endl;
    outfile<<"Welcome... This is the example of append mode"<<endl;

    outfile.close();

    return 0;
}
