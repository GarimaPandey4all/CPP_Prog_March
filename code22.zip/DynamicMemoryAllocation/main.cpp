#include <iostream>

using namespace std;

int main()
{
    //C-Syntax of DMA

//    int *pvalue = NULL;
//
//    pvalue = (int *)malloc(10 * sizeof(int));
//
//    *pvalue = 20;
//
//    cout<<"Value is:"<<*pvalue<<endl;
//
//    free(pvalue);
//    pvalue = NULL;

    //C++ - Syntax of DMA

    int *pvalue = NULL;

    pvalue = new int;

    *pvalue = 20;

    cout<<"Value is:"<<*pvalue<<endl;

    delete pvalue;

    pvalue = NULL;

    return 0;
}
