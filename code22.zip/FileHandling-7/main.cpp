#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    ofstream outfile("Test.txt", ios::out | ios::app);

    outfile<<"This is Write mode example in file handling"<<endl;

    cout<<"Current position of put pointer is:"<<outfile.tellp();

    outfile.close();

    return 0;
}
