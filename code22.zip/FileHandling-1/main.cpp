#include <iostream>
#include <fstream> // fstream: file stream/flow of data

using namespace std;

int main()
{
    //Writing in a file

    ofstream outfile("Test.txt", ios::out);

    //outfile.open("Test.txt", ios::out);

    outfile<<"Hello World"<<endl;
    outfile<<"Welcome here"<<endl;

    outfile.close();

    return 0;
}
