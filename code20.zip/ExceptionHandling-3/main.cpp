#include <iostream>

using namespace std;

int main()
{
    int a, b, c;

    cout<<"Enter value for a and b:";
    cin>>a>>b;

    try
    {
        if(b == 0)
        {
            throw "Divide by zero";
        }

        c = a / b;
        cout<<"Division is:"<<c<<endl;
    }

    catch(char const* e)
    {
        cout<<e<<endl;
    }

//    catch(...)
//    {
//        cout<<"Division by zero Error..."<<endl;
//    }

    return 0;
}
