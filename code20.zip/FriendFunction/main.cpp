#include <iostream>

using namespace std;

/*
    Friend Function:

    1. Friend function is not a member function of a class to which it is a friend.
    2. Friend function is declared in the class with keyword friend.
    3. It must be defined outside the class to which it is a friend.
    4. Friend function can access any member of the class to which it is a friend.
    5. Friend function can't access member of the class directly.
    6. It has no caller object.

*/

class Complex
{
private:
    int a, b;

public:
    void setData(int x, int y)
    {
        a = x;
        b = y;
    }

    void getData()
    {
        cout<<"a is:"<<a<<" b is:"<<b<<endl;
    }

    friend void func(Complex); // declaration of friend function
};

//friend function defined
void func(Complex obj)
{
    cout<<"Sum is:"<<obj.a + obj.b;
}

int main()
{
    Complex C1;

    C1.setData(10, 20);
    C1.getData();

    func(C1);

    return 0;
}
