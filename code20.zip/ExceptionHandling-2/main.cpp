#include <iostream>

using namespace std;

void Myfunc()
{
    if(4 > 3)
    {
        throw 10;
    }
}

int main()
{
    try
    {
        Myfunc();
        cout<<"Try- Block"<<endl;
    }

    catch(...)
    {
        cout<<"Exception Here"<<endl;
    }

    return 0;
}
