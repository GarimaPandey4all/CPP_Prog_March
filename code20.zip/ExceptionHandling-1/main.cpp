#include <iostream>

using namespace std;

/*
    Exception: abnormal condition/error or runtime error

    try
    {}
    throw
    catch
    {}

*/

int main()
{
    cout<<"Exception Handling"<<endl;

    char value = 'A';

    try
    {
        if(value == 23)
            throw 23;
            if(value == 10.23f)
               throw 10.23f;
                if(value == 'C')
                    throw 'C';

        cout<<"Try-block"<<endl;
    }

    catch(int e)
    {
        cout<<"Exception is:"<<e<<endl;
    }

    catch(float e)
    {
        cout<<"Exception is:"<<e<<endl;
    }

    catch(char e)
    {
        cout<<"Exception is:"<<e<<endl;
    }

    cout<<"Outside the try-catch block";

    return 0;
}
