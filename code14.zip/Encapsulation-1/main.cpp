#include <iostream>

using namespace std;

class Encapsulation // Encapsulation example is class
{
public:
    int a, b;

    void display()
    {
        cout<<a<<"  "<<b;
    }
};

int main()
{
    Encapsulation obj;

    obj.a = 10;
    obj.b = 20;

    obj.display();

    return 0;
}
