#include <iostream>

using namespace std;

class Abstraction
{
private:
    int a, b;

public:
    void getData(int x, int y)
    {
        a = x;
        b = y;
    }

    void showData()
    {
        cout<<a<<endl;
        cout<<b<<endl;
    }
};


int main()
{
    Abstraction obj;

//    obj.a = 10;
//    obj.b = 40;
    obj.getData(30, 60);
    obj.showData();

    return 0;
}
