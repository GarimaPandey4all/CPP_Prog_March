#include <iostream>

using namespace std;

class HelloWorld
{
public:
    HelloWorld();
};

HelloWorld :: HelloWorld()
{
    cout<<"Hello World";
}

int main()
{
    HelloWorld obj;

    return 0;
}
