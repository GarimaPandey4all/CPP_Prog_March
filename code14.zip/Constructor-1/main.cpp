#include <iostream>

using namespace std;

class HelloWorld
{
public:
    HelloWorld()  // default constructor
    {
        cout<<"Hello World"<<endl;
    }
};


int main()
{
    HelloWorld obj;

    return 0;
}
