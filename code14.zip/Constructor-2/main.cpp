#include <iostream>

using namespace std;

class Basic
{
    int a, b;

public:
     Basic(int x, int y) // Parameterized Constructor
     {
         a = x;
         b = y;
     }

     void display()
     {
         cout<<a<<"  "<<b<<endl;
     }
};

int main()
{
    Basic obj(30, 60);

    obj.display();

    return 0;
}
