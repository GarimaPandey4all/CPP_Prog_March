#include <iostream>

using namespace std;

class Basic
{
public:

    void showData();
};

void Basic :: showData() // :: Scope Resolution Operator
{
    cout<<"Hello World";
}

int main()
{
    Basic obj;
    obj.showData();

    return 0;
}
