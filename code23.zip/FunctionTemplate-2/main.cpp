#include <iostream>

using namespace std;

//Function Template
template <class T>
T Swap(T a, T b)
{
    T temp = a;
    a = b;
    b = temp;

    cout<<"a is:"<<a<<" b is:"<<b<<endl;
}

int main()
{
    cout<<"Swapping of Integers:"<<endl;
    Swap(10, 50);
    cout<<endl;


    cout<<"Swapping of Float:"<<endl;
    Swap(10.67f, 50.89f);
    cout<<endl;


    cout<<"Swapping of Double:"<<endl;
    Swap(10.78, 50.45);
    cout<<endl;

    return 0;
}
