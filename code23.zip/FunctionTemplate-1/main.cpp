#include <iostream>

using namespace std;

//Function Template
template <class T>
T Add(T a, T b)
{
    cout<<(a + b)<<endl;
}

int main()
{
    cout<<"Addition of Integers:"<<endl;
    Add(10, 20);
    cout<<endl;

    cout<<"Addition of Float:"<<endl;
    Add(10.56f, 20.56f);
    cout<<endl;

    cout<<"Addition of Double:"<<endl;
    Add(34.67, 80.89);
    cout<<endl;

    return 0;
}
