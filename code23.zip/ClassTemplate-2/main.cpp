#include <iostream>

using namespace std;

template <class T>
class MaxNumber
{
private:
    T a, b;

public:

    void setData(T x, T y)
    {
        a = x;
        b = y;
    }

    void getData()
    {
        (a > b) ? cout<<"A is Greater"<<endl : cout<<"B is Greater"<<endl;
    }
};


int main()
{
    MaxNumber<int> obj1;
    obj1.setData(10, 20);

    MaxNumber<float> obj2;
    obj2.setData(10.45f, 20.67f);

    MaxNumber<double> obj3;
    obj3.setData(11.45, 23.56);

    obj1.getData();
    obj2.getData();
    obj3.getData();

    return 0;
}
