#include <iostream>

using namespace std;

template <class T>
class Calculator
{
private:
    T a, b;

public:
    void setData(T x, T y)
    {
        a = x;
        b = y;
    }

    void getData()
    {
        cout<<"Addition is:"<<(a + b)<<endl;
        cout<<"Subtraction is:"<<(a - b)<<endl;
        cout<<"Multiplication is:"<<(a * b)<<endl;
        cout<<"Division is:"<<(a / b)<<endl;
    }
};


int main()
{
    Calculator<int> obj1;
    obj1.setData(30, 20);

    Calculator<float> obj2;
    obj1.setData(30.67f, 20.89f);

    Calculator<double> obj3;
    obj1.setData(30.67, 20.89);

    obj1.getData();
    obj2.getData();
    obj3.getData();

    return 0;
}
