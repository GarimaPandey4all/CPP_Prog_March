#include <iostream>

using namespace std;

class Calculator
{
public:
    int a, b;

    void getData()
    {
        cout<<"Enter value for a and b:";
        cin>>a>>b;
    }

    void showData()
    {
        cout<<"Addition is:"<<(a + b)<<endl;
        cout<<"Subtraction is:"<<(a - b)<<endl;
        cout<<"Multiplication is:"<<(a * b)<<endl;
        cout<<"Division is:"<<(a / b)<<endl;
    }
};


int main()
{
    Calculator obj;

    obj.getData();
    obj.showData();

    return 0;
}
