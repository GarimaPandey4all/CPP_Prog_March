#include <iostream>

using namespace std;

class HelloWorld
{
    /*
        Class:

        1. Data Member
        2. Member Function

    */

    //Acess Modifier/Specifier
    /*
        1. Private
        2. Public
        3. Protected
    */

public:
    void showData()
    {
        cout<<"Hello World"<<endl;
    }

};


int main()
{
    HelloWorld obj;
    HelloWorld obj2;

    obj.showData();
    obj2.showData();

    return 0;
}
