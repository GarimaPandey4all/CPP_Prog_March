#include <iostream>

using namespace std;

class Calculator
{
public:
    int a, b; // Instance Variable

    void getData(int x, int y) // int x, y: Local Variable
    {
        a = x; // instance = local
        b = y;
    }

    void showData()
    {
        cout<<"Addition is:"<<(a + b)<<endl;
        cout<<"Subtraction is:"<<(a - b)<<endl;
        cout<<"Multiplication is:"<<(a * b)<<endl;
        cout<<"Division is:"<<(a / b)<<endl;
    }
};


int main()
{
    Calculator obj;

    obj.getData(10, 20);
    obj.showData();

    return 0;
}
