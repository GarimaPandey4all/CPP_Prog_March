#include <iostream>

using namespace std;

class Shape
{
public:
    virtual void shape()
    {
        cout<<"Shape of Parent Class"<<endl;
    }
};

class Circle : public Shape
{
public:
    void shape() // virtual function must be redefine in child class
    {
        cout<<"Shape of Child Class"<<endl;
    }
};

int main()
{
    Shape *pobj; // Parent's class pointer object
    Circle obj1;

    pobj = &obj1; // assigning the circle class's address  to parent class's object

    //Virtual Function, bind at runtime polymorphism
    pobj->shape();

    return 0;
}
