#include <iostream>

using namespace std;

/*
    Polymorphism: Poly(many) and Morphism(forms)

    Person: Student, Brother, Son, Employee, Father etc...

    Polymorphism has two types:

    1. Compile time Polymorphism
        a) Function Overloading
        b) Operator Overloading

    2. Runtime Polymorphism
        a) Function Overriding : Virtual Function

*/

class FuncOverloading
{
public:
    void Func()
    {
        int a;

        cout<<"Enter value for a:";
        cin>>a;

        cout<<"A is:"<<a<<endl;
    }

    void Func(int x, int y)
    {
        cout<<"x is:"<<x<<endl;
        cout<<"y is:"<<y<<endl;
    }

    void Func(int x, int y, int z)
    {
        cout<<"x is:"<<x<<endl;
        cout<<"y is:"<<y<<endl;
        cout<<"z is:"<<z<<endl;
    }
};


int main()
{
    FuncOverloading obj;

    obj.Func();
    obj.Func(10, 20);
    obj.Func(10, 20, 30);

    return 0;
}
