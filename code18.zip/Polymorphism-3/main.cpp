#include <iostream>

using namespace std;

class Shape
{
public:
    void shape()
    {
        cout<<"Shape of Parent Class"<<endl;
    }
};

class Circle : public Shape
{
public:
    void shape()
    {
        cout<<"Shape of Child Class"<<endl;
    }
};

int main()
{
    Circle obj;
    obj.shape();
    obj.shape();

    return 0;
}
