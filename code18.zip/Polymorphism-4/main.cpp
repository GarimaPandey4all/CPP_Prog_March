#include <iostream>

using namespace std;

class Shape
{
public:
    void shape()
    {
        cout<<"Shape of Parent Class"<<endl;
    }
};

class Circle : public Shape
{
public:
    void shape()
    {
        cout<<"Shape of Child Class"<<endl;
        Shape :: shape();
    }
};

int main()
{
    Circle obj;
    obj.shape();

    return 0;
}
