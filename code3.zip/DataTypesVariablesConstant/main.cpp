#include <iostream>

using namespace std;

int main()
{
    int a = 10;
    float b = 45.67f;
    double c = 34.78;
    char ch = 'R';
    const float pi = 3.14f; // constant variable

    cout<<"a is:"<<a<<endl;
    cout<<"b is:"<<b<<endl;
    cout<<"c is:"<<c<<endl;
    cout<<"ch is:"<<ch<<endl;

    cout<<"size of a:"<<sizeof(a)<<endl;
    cout<<"size of b:"<<sizeof(b)<<endl;
    cout<<"size of c:"<<sizeof(c)<<endl;
    cout<<"size of ch:"<<sizeof(ch)<<endl;

    a = 50;

    cout<<"a is:"<<a<<endl;

    //pi = 56.8f;

    cout<<"PI is:"<<pi<<endl;

    return 0;
}
