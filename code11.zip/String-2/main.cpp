#include <iostream>
#include <string>

using namespace std;

int main()
{
    //char str[10];
    string str;
    string str2;
    string fullName;

    cout<<"Enter String:";
    cin>>str;

    cout<<"Enter String-2";
    cin>>str2;

    cout<<"Length of the String is:"<<str.size()<<endl;

    fullName = str + str2;

    cout<<"Fullname is:"<<fullName;

    return 0;
}
