#include <iostream>

using namespace std;

namespace first
{
    int var = 200;
}

namespace second
{
    int var = 500;
}

int main()
{
    int var = 100;

    cout<<"Var is:"<<var<<endl;

    cout<<"Var is:"<<first::var<<endl;

    cout<<"Var is:"<<second::var<<endl;

    return 0;
}
