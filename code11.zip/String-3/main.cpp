#include <iostream>
#include <cstring>

using namespace std;

/*
    str1 = abc
    str2 = acb

    a - a = 0
    b - c = -1
    c - b = 1

*/

int main()
{
    char str1[10] = "Welcome";
    char str2[10] = "Delhi";
    char str3[10];
    char str4[10] = "DELHI";

    //String Copy
    strcpy(str3, str2);
    cout<<"String - 2 is copying in String - 3:"<<str3<<endl;

    strcat(str1, str2);
    cout<<"String Concatenation is:"<<str1<<endl;

    cout<<"String - 1 Length is:"<<strlen(str1)<<endl;

    if(strcmp(str2, str4) == 0)
    {
        cout<<"Strings are Same"<<endl;
    }
    else
    {
        cout<<"Strings are not Same"<<endl;
    }

    cout<<"Uppercase is:"<<strupr(str1)<<endl;

    cout<<"Lowercase is:"<<strlwr(str4)<<endl;

    return 0;
}
