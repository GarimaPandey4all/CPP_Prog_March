#include <iostream>

using namespace std;

//2. Function without arguments and with return type

int Add(); //Function Declaration

int main()
{
    int result = Add(); // Function Calling

    cout<<"Addition is:"<<result<<endl;

    return 0;
}

//Function Definition/Initialization
int Add()
{
    int a, b;

    cout<<"Enter value for a and b:";
    cin>>a>>b;

    //cout<<"Addition is:"<<(a + b)<<endl;

    return (a + b);
}
