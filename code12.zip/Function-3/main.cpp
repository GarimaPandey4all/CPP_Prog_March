#include <iostream>

using namespace std;

//3. Function with arguments and without return type

void Add(int, int); //Function Declaration

int main()
{
    Add(10, 20); // Function Calling // Actual Arguments

    return 0;
}

//Function Definition/Initialization
void Add(int a, int b) // Formal Arguments / Parameters
{
    cout<<"Addition is:"<<(a + b)<<endl;
}
