#include <iostream>

using namespace std;

/*
    Function or Procedure : Reusability

    Write Once Use Many Times

    Function has four types:

    1. Function without arguments and without return type
    2. Function without arguments and with return type
    3. Function with arguments and without return type
    4. Function with arguments and with return type

*/

//1. Function without arguments and without return type

void Add(); //Function Declaration

int main()
{
    Add(); // Function Calling
    Add();
    Add();

    return 0;
}

//Function Definition/Initialization
void Add() // Function Prototype: return type , function name, function arguments type or number odd types
{
    int a, b;

    cout<<"Enter value for a and b:";
    cin>>a>>b;

    cout<<"Addition is:"<<(a + b)<<endl;
}
