#include <iostream>

using namespace std;

int main()
{
    int hindi, english, maths, social, science, sum = 0, percentage = 0;

    cout<<"Enter your marks:";
    cin>>hindi>>english>>maths>>social>>science;

    sum = hindi + english + maths + social + science;

    cout<<"Total Marks:"<<sum<<endl;

    percentage = sum / 5;

    cout<<"Percentage:"<<percentage<<endl;

    if(percentage >= 50 && percentage <= 60)
    {
        cout<<"Grade D";
    }
    else if(percentage >= 60 && percentage <= 70)
    {
        cout<<"Grade C";
    }
    else if(percentage >= 70 && percentage <= 80)
    {
        cout<<"Grade B";
    }
    else if(percentage >= 80 && percentage <= 100)
    {
        cout<<"Grade A";
    }
    else
    {
        cout<<"Fail..";
    }

    return 0;
}
