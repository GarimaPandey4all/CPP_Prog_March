#include <iostream>

using namespace std;

int main()
{
    char opr;
    int a, b;

    while(1) // 1- always true
    {
    cout<<endl<<endl<<"<---Calculator--->"<<endl<<endl;
    cout<<"Press +. Addition"<<endl;
    cout<<"Press -. Subtraction"<<endl;
    cout<<"Press *. Multiplication"<<endl;
    cout<<"Press /. Division"<<endl;
    cout<<"Press e. Exit"<<endl;
    cout<<endl<<endl<<"Enter your choice:";
    cin>>opr;

    switch(opr)
    {
    case '+':
        cout<<"Enter any value for a and b:";
        cin>>a >>b;

        cout<<"Addition is:"<<(a + b)<<endl;
        break;

    case '-':
        cout<<"Enter any value for a and b:";
        cin>>a >>b;

        cout<<"Subtraction is:"<<(a - b)<<endl;
        break;

    case '*':
        cout<<"Enter any value for a and b:";
        cin>>a >>b;

        cout<<"Multiplication is:"<<(a * b)<<endl;
        break;

    case '/':
        cout<<"Enter any value for a and b:";
        cin>>a >>b;

        cout<<"Division is:"<<(a / b)<<endl;
        break;

    case 'e':
        exit(0);

    default:
        cout<<"Invalid Operator";
    }
    }

    //cout<<"Outside the Switch-Block";

    return 0;
}
