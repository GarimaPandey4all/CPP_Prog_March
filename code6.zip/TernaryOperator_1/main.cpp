#include <iostream>

using namespace std;

int main()
{
    int a, b;

    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    //(condition) ? True : False

    (a > b) ? cout<<"A is Greater" : cout<<"B is Greater";

    return 0;
}
