#include <iostream>

using namespace std;

class Vehicle
{
public:
    Vehicle()
    {
        cout<<"Vehicle Class"<<endl;
    }
};

class FourWheeler
{
public:
    FourWheeler()
    {
        cout<<"FourWheeler"<<endl;
    }
};

class Car : public Vehicle, public FourWheeler
{
public:
    Car()
    {
        cout<<"Car Class"<<endl;
    }
};

class Bus : public Vehicle
{
public:
    Bus()
    {
        cout<<"Bus Class"<<endl;
    }
};

int main()
{
    Car obj;
    Bus obj2;

    return 0;
}
