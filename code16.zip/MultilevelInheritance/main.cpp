#include <iostream>

using namespace std;

class Parent
{
public:
    Parent()
    {
        cout<<"This is Parent Class"<<endl;
    }
};

class Child1 : public Parent
{
public:
    Child1()
    {
        cout<<"This is Child-1 Class"<<endl;
    }
};

class Child2 : public Child1
{
public:
    Child2()
    {
        cout<<"This is Child-2 Class"<<endl;
    }
};

int main()
{
    Child2 obj;

    return 0;
}
