#include <iostream>

using namespace std;

//Destructor: Delete the object, it is called automatically.

class HelloWorld
{
public:
    HelloWorld() // Constructor
    {
        cout<<"Constructor"<<endl;
    }

    ~HelloWorld() // Destructor
    {
        cout<<"Destructor"<<endl;
    }

    void display()
    {
        cout<<"Hello World"<<endl;
    }
};

int main()
{
    HelloWorld obj;
    obj.display();

    return 0;
}
