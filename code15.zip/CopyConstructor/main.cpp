#include <iostream>

using namespace std;

class CC
{
public:
    int a;

    CC(int x)
    {
        a = x;
    }

    CC(CC &t) // copy constructor
    {
        a = t.a;
    }
};

int main()
{
    CC obj1(10); //Calling Parameterized Constructor
    CC obj2(obj1); // Calling Copy Constructor

    cout<<"A od obj2 is:"<<obj2.a<<endl;

    return 0;
}
