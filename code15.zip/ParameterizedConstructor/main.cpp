#include <iostream>

using namespace std;

class DC
{
public:
    int a, b;

    DC(int x, int y)
    {
        a = x;
        b = y;
    }

    void showData()
    {
        cout<<a<<"  "<<b;
    }
};


int main()
{
    DC obj(10, 20);
    obj.showData();

    return 0;
}
