#include <iostream> // Pre-Processor Directives

//iostream: Input/Output Stream/flow of Data

using namespace std;


//function's return type
int main() // main() - Entry Point or Initial Point
{
    //std::cout << "Hello world!" << std::endl;

    cout<<"Hello World"<<endl; // print output on the output/console screen

    return 0;
}
