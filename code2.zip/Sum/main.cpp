#include <iostream>

using namespace std;

int main()
{
    int a, b;

    cout<<"Enter any value for a and b:";
    cin>>a>>b; // Read User Input

    cout<<"Addition is:"<<a + b<<endl;

    return 0;
}
