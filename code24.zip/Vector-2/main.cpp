#include <iostream>
#include <vector>

using namespace std;

int main()
{
    vector <int> v1;
    vector <char> v2;
    vector <int> v3(5, 10); // size - 5 and value-10
    vector <string> v4(4, "hi");

    //Subscript Operator- []

    cout<<v4[0]<<endl;
    cout<<v4[1]<<endl;
    cout<<v4[2]<<endl;
    cout<<v4[3]<<endl;

    cout<<"At()"<<v3.at(2)<<endl;
    cout<<"Front()"<<v3.front()<<endl;
    cout<<"Back()"<<v4.back()<<endl;

    return 0;
}
