#include <iostream>
#include <vector>

using namespace std;

/*
    Vector: It supports dynamic Array.
    Vector can provide memory flexibility.
*/

int main()
{
    vector <int> v1;

    cout<<"Current Capacity is:"<<v1.capacity()<<endl;

    vector <string> v2 {"Yash", "Garima", "Ekta", "Brain", "Mentors"};

    cout<<"Current Capacity is:"<<v2.capacity()<<endl;

    return 0;
}
