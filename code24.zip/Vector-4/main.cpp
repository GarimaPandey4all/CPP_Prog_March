#include <iostream>
#include <vector>

using namespace std;

int main()
{
    vector <int> v1;

    for(int i = 0; i < 10; i++)
    {
        v1.push_back(10 * (i + 1));
    }

    for(int i = 0; i < v1.size(); i++)
    {
        cout<<v1[i]<<"  ";
    }

    cout<<endl;

    //Insert at particular location

    vector <int> :: iterator ptr = v1.begin();

    v1.insert(ptr + 3, 35);

    for(int i = 0; i < v1.size(); i++)
    {
        cout<<v1[i]<<"  ";
    }

    cout<<endl;

    cout<<"Size is:"<<v1.size()<<endl;
    cout<<"Capacity is:"<<v1.capacity()<<endl;

    return 0;
}
