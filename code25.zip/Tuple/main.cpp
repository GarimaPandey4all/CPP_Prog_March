#include <iostream>
#include <tuple>

using namespace std;

int main()
{
    tuple <string, int, int> t1;

    //Insert into a tuple
    t1 = make_tuple("New Delhi", 10, 25);

    //Accessing values from the tuple
    cout<<"Tuple 1:"<<get<0>(t1)<<"  "<<get<1>(t1)<<"  "<<get<2>(t1)<<endl;

    return 0;
}
