#include <iostream>
#include <map>

using namespace std;

int main()
{
    map <int, string> customer;

    customer[100] = "Akshika";
    customer[145] = "Rahul";
    customer[160] = "Ujjwal";
    customer[101] = "Brain";
    customer[110] = "Mentors";

    //Accessing values from the map: first way

    cout<<"Customer 1:"<<customer[100]<<endl;
    cout<<"Customer 2:"<<customer[145]<<endl;
    cout<<"Customer 3:"<<customer[160]<<endl;
    cout<<"Customer 4:"<<customer[101]<<endl;
    cout<<"Customer 5:"<<customer[110]<<endl;

    //Insert using insert() in map:

    customer.insert(pair<int, string>(166, "Technology"));

    //at()

    cout<<"Customer 6:"<<customer.at(166)<<endl;

    //Accessing values from the map: second way

    map <int, string> :: iterator ptr = customer.begin();

    while(ptr != customer.end())
    {
        cout<<ptr->first<<endl;
        cout<<ptr->second<<endl;

        ++ptr;
    }

    cout<<"Total number of elements:"<<customer.size()<<endl;

    //empty()

    cout<<"is Array empty or not?"<<customer.empty()<<endl;


    return 0;
}
