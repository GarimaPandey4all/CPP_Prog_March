#include <iostream>
#include <list>

using namespace std;

int main()
{
    list <int> l1{50, 40, 30, 20, 10};

    list <int> :: iterator ptr = l1.begin();

    while(ptr != l1.end())
    {
        cout<<*ptr<<endl;
        ++ptr;
    }

    cout<<"\nTotal values in list are:"<<l1.size()<<endl;

    //l1.remove(10);

    //l1.sort();

    l1.reverse();

    list <int> :: iterator ptr1 = l1.begin();

    while(ptr1 != l1.end())
    {
        cout<<*ptr1<<endl;
        ++ptr1;
    }

    cout<<"\nTotal values in list are:"<<l1.size()<<endl;

    l1.clear();

//    list <int> :: iterator ptr2 = l1.begin();
//
//    while(ptr2 != l1.end())
//    {
//        cout<<*ptr2<<endl;
//        ++ptr2;
//    }

    cout<<"\nTotal values in list are:"<<l1.size()<<endl;

    return 0;
}
