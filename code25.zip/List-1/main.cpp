#include <iostream>
#include <list>

using namespace std;

int main()
{
    list <int> l1;
    list <int> l2 {10, 20, 30, 40, 50, 60, 70, 80, 90};

    list <string> l3 {"Mumbai", "New Delhi"};

    //cout<<l3[0]<<endl; // error

    list <int> :: iterator ptr = l2.begin();

    while(ptr != l2.end())
    {
        cout<<*ptr<<"  ";
        ++ptr;
    }

    cout<<"\nTotal values in list are:"<<l2.size();

    return 0;
}
