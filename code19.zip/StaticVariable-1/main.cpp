#include <iostream>

using namespace std;

/*
    Static Member Variable:

    1. Also known as Class Member variable
    2. They must be defined outside the class
    3. Does not belong to any object but to the whole class.
    4. There will be only one copy of static member variable for the whole class.
    5. Any object can use the same copy of class variable.
    6. They can also be used with the class name.

*/

class Student
{
private:
    int rollno;
    static int marks;

public:
    void setData(int r)
    {
        rollno = r;
    }

    void getData()
    {
        cout<<"Roll no:"<<rollno<<endl;
        cout<<"Marks:"<<marks<<endl;
    }
};

int Student :: marks = 530; // static variable defined

int main()
{
    Student obj;
    obj.setData(10);
    obj.getData();

    return 0;
}
