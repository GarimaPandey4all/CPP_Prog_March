#include <iostream>

using namespace std;

/*
    Operators Types:

    1. Arithmetic Operators
    2. Relational Operators
    3. Logical Operators
    4. Assignment Operators
    5. Bitwise Operators

*/

int main()
{
    int a, b;

    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    cout<<"Addition is:"<<(a + b)<<endl;
    cout<<"Subtraction is:"<<(a - b)<<endl;
    cout<<"Multiplication is:"<<(a * b)<<endl;
    cout<<"Division is:"<<(a / b)<<endl;
    cout<<"Modulus is:"<<(a % b)<<endl;
    cout<<"Pre-Increment is:"<<(++a)<<endl;
    cout<<"Post-Increment is:"<<(a++)<<endl;
    cout<<"Pre-Decrement is:"<<(--b)<<endl;
    cout<<"Post-Decrement is:"<<(b--)<<endl;

    return 0;
}
