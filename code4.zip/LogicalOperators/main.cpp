#include <iostream>

using namespace std;

int main()
{
    int a, b;

    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    cout<<"AND Logical Operators:"<<(a > 10 && b < 20)<<endl;
    cout<<"OR Logical Operators:"<<(a > 10 || b < 20)<<endl;
    cout<<"Not Logical Operators:"<<!(a > 10 && b < 20)<<endl;

    return 0;
}
