#include <iostream>

using namespace std;

int main()
{
    int a = 50; // assignment

    a += 100; //a = a + 100;

    a *= 4; // a = a * 4

    a <<= 2; // a = a << 2;

    cout<<"a is:"<<a<<endl;

    return 0;
}
