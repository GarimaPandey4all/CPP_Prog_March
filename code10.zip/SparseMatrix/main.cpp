#include <iostream>

using namespace std;

int main()
{
    int matrix[5][5], rows, cols, totalCount = 0;

    cout<<"Enter rows:";
    cin>>rows;

    cout<<"Enter Columns:";
    cin>>cols;

    cout<<"Enter values in Matrix:";
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            cin>>matrix[i][j];
        }
    }

    cout<<"Values in Matrix:\n";
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            cout<<matrix[i][j]<<"\t";
        }
        cout<<endl;
    }

    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            if(matrix[i][j] == 0)
            {
                totalCount++;
            }
        }
    }

    if(totalCount > (rows * cols) / 2)
    {
        cout<<"Sparse Matrix";
    }
    else
    {
        cout<<"Not Sparse Matrix";
    }

    return 0;
}
