#include <iostream>

using namespace std;

int main()
{
    int matrix[5][5], rows, cols;

    cout<<"Enter rows:";
    cin>>rows;

    cout<<"Enter Columns:";
    cin>>cols;

    cout<<"Enter values in Matrix:";
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            cin>>matrix[i][j];
        }
    }

    cout<<"Values in Matrix:\n";
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            cout<<matrix[i][j]<<"\t";
        }
        cout<<endl;
    }

    cout<<"Principle Diagonal Matrix is:\n";
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            if(i == j)
            {
                cout<<matrix[i][j]<<"\t";
            }
        }
    }

    return 0;
}
