#include <iostream>

using namespace std;

/*
    Decision Making Statements:

    1. If-Else
    2. If-Else if-Else
    3. Switch

    Ternary/Conditional Operator; Shorthand of If-Else
*/

int main()
{
    int a, b;

    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    if(a > b)
    {
        cout<<"A is Greater";
    }
    else
    {
        cout<<"B is Greater";
    }

    return 0;
}
