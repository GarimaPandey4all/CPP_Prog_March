#include <iostream>

using namespace std;

int main()
{
    int a, b;

    cout<<"Enter any value for a and b:";
    cin>>a>>b;

//    cout<<"Before Swapping a="<<a<<" and b="<<b<<endl;
//
//    //First Way
//
//    a = a + b; // 9
//    b = a - b; // 4
//    a = a - b; // 5
//
//    cout<<"After Swapping a="<<a<<" and b="<<b<<endl;

//    cout<<"Before Swapping a="<<a<<" and b="<<b<<endl;
//
//    //Second Way
//
//    a = a * b; // 20
//    b = a / b; // 4
//    a = a / b; // 5
//
//    cout<<"After Swapping a="<<a<<" and b="<<b<<endl;

    cout<<"Before Swapping a="<<a<<" and b="<<b<<endl;

    //Third Way

    a = a ^ b; //
    b = a ^ b; //
    a = a ^ b; //

    cout<<"After Swapping a="<<a<<" and b="<<b<<endl;

    return 0;
}
