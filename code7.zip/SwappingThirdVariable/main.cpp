#include <iostream>

using namespace std;

int main()
{
    int a, b;

    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    cout<<"Before Swapping a="<<a<<" and b="<<b<<endl;

    int temp = a;
    a = b;
    b = temp;

    cout<<"After Swapping a="<<a<<" and b="<<b<<endl;

    return 0;
}
